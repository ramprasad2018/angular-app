package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.SupplierProfile;
import com.agroconnect.supplier.repository.SupplierProfileRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierProfileService {
    private final SupplierProfileRepository repository;

    public SupplierProfileService(SupplierProfileRepository repository) {
        this.repository = repository;
    }

    public SupplierProfile save(SupplierProfile obj) {
        return repository.save(obj);
    }

    public List<SupplierProfile> findAll() {
        return (List<SupplierProfile>) repository.findAll();
    }

    public List<SupplierProfile> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
