package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.TopSellingProducts;
import com.agroconnect.supplier.repository.TopSellingProductsRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TopSellingProductsService {
    private final TopSellingProductsRepository repository;

    public TopSellingProductsService(TopSellingProductsRepository repository) {
        this.repository = repository;
    }

    public TopSellingProducts save(TopSellingProducts obj) {
        return repository.save(obj);
    }

    public List<TopSellingProducts> findAll() {
        return (List<TopSellingProducts>) repository.findAll();
    }

    public List<TopSellingProducts> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
