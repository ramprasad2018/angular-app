package com.agroconnect.supplier.repository;

import com.agroconnect.supplier.model.ContractSummary;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.time.Instant;

@Repository
public interface ContractSummaryRepository extends RedisDocumentRepository<ContractSummary, String> {
    List<ContractSummary> findBySupplierId(String supplierId);
}
