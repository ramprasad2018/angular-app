package com.agroconnect.supplier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgroconnectSupplierApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgroconnectSupplierApplication.class, args);
    }
}
