package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.SupplierSession;
import com.agroconnect.supplier.service.SupplierSessionService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/suppliersession")
public class SupplierSessionController {
    private final SupplierSessionService service;

    public SupplierSessionController(SupplierSessionService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save SupplierSession record")
    public SupplierSession save(@RequestBody SupplierSession obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all SupplierSession records")
    public List<SupplierSession> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get SupplierSession records by Supplier ID")
    public List<SupplierSession> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
