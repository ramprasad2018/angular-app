package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.OtpToken;
import com.agroconnect.supplier.service.OtpTokenService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/otptoken")
public class OtpTokenController {
    private final OtpTokenService service;

    public OtpTokenController(OtpTokenService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save OtpToken record")
    public OtpToken save(@RequestBody OtpToken obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all OtpToken records")
    public List<OtpToken> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get OtpToken records by Supplier ID")
    public List<OtpToken> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
