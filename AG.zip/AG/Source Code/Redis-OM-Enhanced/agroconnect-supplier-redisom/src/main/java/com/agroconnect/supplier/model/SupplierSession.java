package com.agroconnect.supplier.model;

import com.redis.om.spring.annotations.*;
import lombok.Data;
import org.springframework.data.annotation.Id;
import java.time.*;
import java.util.*;

@Data
@Document
public class SupplierSession {
    @Id
    private String sessionId;
    @Indexed
    private String supplierId;
    private Instant loginTime;
    private Instant expiresAt;
}