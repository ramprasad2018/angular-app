package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.ProductCatalog;
import com.agroconnect.supplier.service.ProductCatalogService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/productcatalog")
public class ProductCatalogController {
    private final ProductCatalogService service;

    public ProductCatalogController(ProductCatalogService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save ProductCatalog record")
    public ProductCatalog save(@RequestBody ProductCatalog obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all ProductCatalog records")
    public List<ProductCatalog> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get ProductCatalog records by Supplier ID")
    public List<ProductCatalog> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
