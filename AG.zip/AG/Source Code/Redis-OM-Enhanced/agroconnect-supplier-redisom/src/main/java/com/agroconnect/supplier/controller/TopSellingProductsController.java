package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.TopSellingProducts;
import com.agroconnect.supplier.service.TopSellingProductsService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/topsellingproducts")
public class TopSellingProductsController {
    private final TopSellingProductsService service;

    public TopSellingProductsController(TopSellingProductsService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save TopSellingProducts record")
    public TopSellingProducts save(@RequestBody TopSellingProducts obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all TopSellingProducts records")
    public List<TopSellingProducts> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get TopSellingProducts records by Supplier ID")
    public List<TopSellingProducts> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
