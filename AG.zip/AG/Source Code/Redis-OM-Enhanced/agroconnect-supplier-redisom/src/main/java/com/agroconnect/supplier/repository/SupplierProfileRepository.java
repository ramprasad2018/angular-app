package com.agroconnect.supplier.repository;

import com.agroconnect.supplier.model.SupplierProfile;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.time.Instant;

@Repository
public interface SupplierProfileRepository extends RedisDocumentRepository<SupplierProfile, String> {
    List<SupplierProfile> findBySupplierId(String supplierId);
}
