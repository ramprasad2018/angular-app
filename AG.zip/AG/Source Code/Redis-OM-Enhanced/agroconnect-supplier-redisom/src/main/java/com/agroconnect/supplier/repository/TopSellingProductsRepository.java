package com.agroconnect.supplier.repository;

import com.agroconnect.supplier.model.TopSellingProducts;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.time.Instant;

@Repository
public interface TopSellingProductsRepository extends RedisDocumentRepository<TopSellingProducts, String> {
    List<TopSellingProducts> findBySupplierId(String supplierId);
}
