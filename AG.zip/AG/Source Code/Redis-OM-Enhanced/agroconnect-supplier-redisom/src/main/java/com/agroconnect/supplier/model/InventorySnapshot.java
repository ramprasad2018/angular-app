package com.agroconnect.supplier.model;

import com.redis.om.spring.annotations.*;
import lombok.Data;
import org.springframework.data.annotation.Id;
import java.time.*;
import java.util.*;

@Data
@Document
public class InventorySnapshot {
    @Id
    private String id;
    @Indexed
    private String supplierId;
    private Map<String, Integer> stockMap;
    private Instant capturedAt;
}