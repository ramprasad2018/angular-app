package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.ContractSummary;
import com.agroconnect.supplier.service.ContractSummaryService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/contractsummary")
public class ContractSummaryController {
    private final ContractSummaryService service;

    public ContractSummaryController(ContractSummaryService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save ContractSummary record")
    public ContractSummary save(@RequestBody ContractSummary obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all ContractSummary records")
    public List<ContractSummary> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get ContractSummary records by Supplier ID")
    public List<ContractSummary> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
