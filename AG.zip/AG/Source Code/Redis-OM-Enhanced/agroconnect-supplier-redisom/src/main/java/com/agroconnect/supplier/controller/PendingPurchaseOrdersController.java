package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.PendingPurchaseOrders;
import com.agroconnect.supplier.service.PendingPurchaseOrdersService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pendingpurchaseorders")
public class PendingPurchaseOrdersController {
    private final PendingPurchaseOrdersService service;

    public PendingPurchaseOrdersController(PendingPurchaseOrdersService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save PendingPurchaseOrders record")
    public PendingPurchaseOrders save(@RequestBody PendingPurchaseOrders obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all PendingPurchaseOrders records")
    public List<PendingPurchaseOrders> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get PendingPurchaseOrders records by Supplier ID")
    public List<PendingPurchaseOrders> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
