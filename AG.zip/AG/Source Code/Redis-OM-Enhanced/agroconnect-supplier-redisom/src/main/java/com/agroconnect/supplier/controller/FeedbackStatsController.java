package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.FeedbackStats;
import com.agroconnect.supplier.service.FeedbackStatsService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/feedbackstats")
public class FeedbackStatsController {
    private final FeedbackStatsService service;

    public FeedbackStatsController(FeedbackStatsService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save FeedbackStats record")
    public FeedbackStats save(@RequestBody FeedbackStats obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all FeedbackStats records")
    public List<FeedbackStats> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get FeedbackStats records by Supplier ID")
    public List<FeedbackStats> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
