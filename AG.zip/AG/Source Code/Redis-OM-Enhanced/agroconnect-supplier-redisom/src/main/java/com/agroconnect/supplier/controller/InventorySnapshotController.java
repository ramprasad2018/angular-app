package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.InventorySnapshot;
import com.agroconnect.supplier.service.InventorySnapshotService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventorysnapshot")
public class InventorySnapshotController {
    private final InventorySnapshotService service;

    public InventorySnapshotController(InventorySnapshotService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save InventorySnapshot record")
    public InventorySnapshot save(@RequestBody InventorySnapshot obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all InventorySnapshot records")
    public List<InventorySnapshot> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get InventorySnapshot records by Supplier ID")
    public List<InventorySnapshot> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
