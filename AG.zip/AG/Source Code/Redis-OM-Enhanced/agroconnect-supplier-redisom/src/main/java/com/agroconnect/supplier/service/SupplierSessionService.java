package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.SupplierSession;
import com.agroconnect.supplier.repository.SupplierSessionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierSessionService {
    private final SupplierSessionRepository repository;

    public SupplierSessionService(SupplierSessionRepository repository) {
        this.repository = repository;
    }

    public SupplierSession save(SupplierSession obj) {
        return repository.save(obj);
    }

    public List<SupplierSession> findAll() {
        return (List<SupplierSession>) repository.findAll();
    }

    public List<SupplierSession> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
