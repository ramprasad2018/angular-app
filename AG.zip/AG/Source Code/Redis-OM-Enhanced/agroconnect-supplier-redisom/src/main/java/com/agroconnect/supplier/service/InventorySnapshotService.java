package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.InventorySnapshot;
import com.agroconnect.supplier.repository.InventorySnapshotRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventorySnapshotService {
    private final InventorySnapshotRepository repository;

    public InventorySnapshotService(InventorySnapshotRepository repository) {
        this.repository = repository;
    }

    public InventorySnapshot save(InventorySnapshot obj) {
        return repository.save(obj);
    }

    public List<InventorySnapshot> findAll() {
        return (List<InventorySnapshot>) repository.findAll();
    }

    public List<InventorySnapshot> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
