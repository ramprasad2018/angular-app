package com.agroconnect.supplier.repository;

import com.agroconnect.supplier.model.PendingPurchaseOrders;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.time.Instant;

@Repository
public interface PendingPurchaseOrdersRepository extends RedisDocumentRepository<PendingPurchaseOrders, String> {
    List<PendingPurchaseOrders> findBySupplierId(String supplierId);
}
