package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.CompletedOrders;
import com.agroconnect.supplier.repository.CompletedOrdersRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompletedOrdersService {
    private final CompletedOrdersRepository repository;

    public CompletedOrdersService(CompletedOrdersRepository repository) {
        this.repository = repository;
    }

    public CompletedOrders save(CompletedOrders obj) {
        return repository.save(obj);
    }

    public List<CompletedOrders> findAll() {
        return (List<CompletedOrders>) repository.findAll();
    }

    public List<CompletedOrders> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
