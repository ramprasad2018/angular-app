package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.CompletedOrders;
import com.agroconnect.supplier.service.CompletedOrdersService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/completedorders")
public class CompletedOrdersController {
    private final CompletedOrdersService service;

    public CompletedOrdersController(CompletedOrdersService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save CompletedOrders record")
    public CompletedOrders save(@RequestBody CompletedOrders obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all CompletedOrders records")
    public List<CompletedOrders> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get CompletedOrders records by Supplier ID")
    public List<CompletedOrders> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
