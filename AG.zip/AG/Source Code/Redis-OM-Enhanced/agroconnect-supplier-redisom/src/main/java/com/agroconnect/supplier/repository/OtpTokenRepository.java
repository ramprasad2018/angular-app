package com.agroconnect.supplier.repository;

import com.agroconnect.supplier.model.OtpToken;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.time.Instant;

@Repository
public interface OtpTokenRepository extends RedisDocumentRepository<OtpToken, String> {
    List<OtpToken> findBySupplierId(String supplierId);
}
