package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.ContractSummary;
import com.agroconnect.supplier.repository.ContractSummaryRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContractSummaryService {
    private final ContractSummaryRepository repository;

    public ContractSummaryService(ContractSummaryRepository repository) {
        this.repository = repository;
    }

    public ContractSummary save(ContractSummary obj) {
        return repository.save(obj);
    }

    public List<ContractSummary> findAll() {
        return (List<ContractSummary>) repository.findAll();
    }

    public List<ContractSummary> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
