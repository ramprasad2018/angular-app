package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.OtpToken;
import com.agroconnect.supplier.repository.OtpTokenRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OtpTokenService {
    private final OtpTokenRepository repository;

    public OtpTokenService(OtpTokenRepository repository) {
        this.repository = repository;
    }

    public OtpToken save(OtpToken obj) {
        return repository.save(obj);
    }

    public List<OtpToken> findAll() {
        return (List<OtpToken>) repository.findAll();
    }

    public List<OtpToken> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
