package com.agroconnect.supplier.repository;

import com.agroconnect.supplier.model.SupplierSession;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.time.Instant;

@Repository
public interface SupplierSessionRepository extends RedisDocumentRepository<SupplierSession, String> {
    List<SupplierSession> findBySupplierId(String supplierId);
}
