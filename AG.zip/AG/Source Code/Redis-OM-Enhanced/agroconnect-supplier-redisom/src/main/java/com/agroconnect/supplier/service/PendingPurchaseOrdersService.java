package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.PendingPurchaseOrders;
import com.agroconnect.supplier.repository.PendingPurchaseOrdersRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PendingPurchaseOrdersService {
    private final PendingPurchaseOrdersRepository repository;

    public PendingPurchaseOrdersService(PendingPurchaseOrdersRepository repository) {
        this.repository = repository;
    }

    public PendingPurchaseOrders save(PendingPurchaseOrders obj) {
        return repository.save(obj);
    }

    public List<PendingPurchaseOrders> findAll() {
        return (List<PendingPurchaseOrders>) repository.findAll();
    }

    public List<PendingPurchaseOrders> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
