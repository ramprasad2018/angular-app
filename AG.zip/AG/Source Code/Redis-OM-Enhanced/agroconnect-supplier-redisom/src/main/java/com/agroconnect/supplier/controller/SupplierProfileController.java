package com.agroconnect.supplier.controller;

import com.agroconnect.supplier.model.SupplierProfile;
import com.agroconnect.supplier.service.SupplierProfileService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/supplierprofile")
public class SupplierProfileController {
    private final SupplierProfileService service;

    public SupplierProfileController(SupplierProfileService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Save SupplierProfile record")
    public SupplierProfile save(@RequestBody SupplierProfile obj) {
        return service.save(obj);
    }

    @GetMapping
    @Operation(summary = "Get all SupplierProfile records")
    public List<SupplierProfile> getAll() {
        return service.findAll();
    }

    @GetMapping("/supplier/{supplierId}")
    @Operation(summary = "Get SupplierProfile records by Supplier ID")
    public List<SupplierProfile> getBySupplierId(@PathVariable String supplierId) {
        return service.findBySupplierId(supplierId);
    }
}
