package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.ProductCatalog;
import com.agroconnect.supplier.repository.ProductCatalogRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductCatalogService {
    private final ProductCatalogRepository repository;

    public ProductCatalogService(ProductCatalogRepository repository) {
        this.repository = repository;
    }

    public ProductCatalog save(ProductCatalog obj) {
        return repository.save(obj);
    }

    public List<ProductCatalog> findAll() {
        return (List<ProductCatalog>) repository.findAll();
    }

    public List<ProductCatalog> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
