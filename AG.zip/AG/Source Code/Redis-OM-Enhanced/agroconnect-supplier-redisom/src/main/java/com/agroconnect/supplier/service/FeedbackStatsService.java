package com.agroconnect.supplier.service;

import com.agroconnect.supplier.model.FeedbackStats;
import com.agroconnect.supplier.repository.FeedbackStatsRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeedbackStatsService {
    private final FeedbackStatsRepository repository;

    public FeedbackStatsService(FeedbackStatsRepository repository) {
        this.repository = repository;
    }

    public FeedbackStats save(FeedbackStats obj) {
        return repository.save(obj);
    }

    public List<FeedbackStats> findAll() {
        return (List<FeedbackStats>) repository.findAll();
    }

    public List<FeedbackStats> findBySupplierId(String supplierId) {
        return repository.findBySupplierId(supplierId);
    }
}
