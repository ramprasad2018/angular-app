package com.agroconnect.service;

import com.agroconnect.model.Crop;
import com.agroconnect.model.Farmer;
import com.agroconnect.repository.CropRepository;
import com.agroconnect.repository.FarmerRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FarmerService {
    private final FarmerRepository farmerRepository;
    private final CropRepository cropRepository;

    public FarmerService(FarmerRepository farmerRepository, CropRepository cropRepository) {
        this.farmerRepository = farmerRepository;
        this.cropRepository = cropRepository;
    }

    public Farmer saveFarmer(Farmer farmer) {
        return farmerRepository.save(farmer);
    }

    public Crop saveCrop(Crop crop) {
        return cropRepository.save(crop);
    }

    public List<Crop> getCropsForFarmer(String farmerId) {
        Optional<Farmer> farmerOpt = farmerRepository.findById(farmerId);
        return farmerOpt.map(farmer -> cropRepository.findAllById(farmer.getCropIds()))
                        .orElse(List.of());
    }
}
