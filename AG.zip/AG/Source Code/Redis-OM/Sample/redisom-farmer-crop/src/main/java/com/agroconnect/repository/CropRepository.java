package com.agroconnect.repository;

import com.agroconnect.model.Crop;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CropRepository extends RedisDocumentRepository<Crop, String> {
}
