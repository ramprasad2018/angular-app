package com.agroconnect.model;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.Indexed;
import lombok.Data;
import org.springframework.data.annotation.Id;

@Data
@Document
public class Crop {
    @Id
    private String id;

    @Indexed
    private String name;

    private String type;
    private String season;
}
