package com.agroconnect.controller;

import com.agroconnect.model.Crop;
import com.agroconnect.model.Farmer;
import com.agroconnect.service.FarmerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class FarmerController {

    private final FarmerService farmerService;

    public FarmerController(FarmerService farmerService) {
        this.farmerService = farmerService;
    }

    @PostMapping("/farmers")
    public Farmer saveFarmer(@RequestBody Farmer farmer) {
        return farmerService.saveFarmer(farmer);
    }

    @PostMapping("/crops")
    public Crop saveCrop(@RequestBody Crop crop) {
        return farmerService.saveCrop(crop);
    }

    @GetMapping("/farmers/{id}/crops")
    public List<Crop> getFarmerCrops(@PathVariable String id) {
        return farmerService.getCropsForFarmer(id);
    }
}
