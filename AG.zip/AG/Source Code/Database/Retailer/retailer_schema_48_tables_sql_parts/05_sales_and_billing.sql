-- 5. Sales & Billing (Outbound)
CREATE TABLE retailer.sales_invoice (
    id SERIAL PRIMARY KEY,
    retailer_id INTEGER REFERENCES retailer.retailer(id),
    invoice_date DATE,
    total_amount NUMERIC,
    payment_status TEXT
);

CREATE TABLE retailer.sales_invoice_item (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES retailer.sales_invoice(id),
    product_id INTEGER REFERENCES retailer.product(id),
    quantity INTEGER,
    price_per_unit NUMERIC
);

CREATE TABLE retailer.sales_payment (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES retailer.sales_invoice(id),
    payment_method TEXT,
    paid_amount NUMERIC,
    payment_date DATE
);

CREATE TABLE retailer.discount_coupon (
    id SERIAL PRIMARY KEY,
    code TEXT UNIQUE,
    discount_value NUMERIC,
    valid_from DATE,
    valid_to DATE,
    is_active BOOLEAN DEFAULT true
);