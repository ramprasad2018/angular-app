-- 3. Inventory Management
CREATE TABLE retailer.stock_ledger (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    opening_stock INTEGER,
    inward_stock INTEGER,
    outward_stock INTEGER,
    closing_stock INTEGER,
    record_date DATE
);

CREATE TABLE retailer.batch_stock (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    batch_number TEXT,
    expiry_date DATE,
    quantity INTEGER
);

CREATE TABLE retailer.low_stock_alert (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    threshold_quantity INTEGER,
    alerted BOOLEAN DEFAULT false
);

CREATE TABLE retailer.stock_adjustment (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    reason TEXT,
    quantity_changed INTEGER,
    adjusted_at TIMESTAMP
);