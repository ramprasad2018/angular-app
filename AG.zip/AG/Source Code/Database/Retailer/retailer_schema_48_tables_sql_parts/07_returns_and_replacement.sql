-- 7. Returns & Replacement
CREATE TABLE retailer.sales_return (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES retailer.sales_invoice(id),
    reason TEXT,
    returned_at TIMESTAMP
);

CREATE TABLE retailer.supplier_return (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    quantity INTEGER,
    reason TEXT,
    returned_at TIMESTAMP
);

CREATE TABLE retailer.replacement_transaction (
    id SERIAL PRIMARY KEY,
    original_product_id INTEGER REFERENCES retailer.product(id),
    replacement_product_id INTEGER REFERENCES retailer.product(id),
    quantity INTEGER,
    replaced_at TIMESTAMP
);

CREATE TABLE retailer.credit_note (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES retailer.customer_profile(id),
    amount NUMERIC,
    issued_date DATE
);