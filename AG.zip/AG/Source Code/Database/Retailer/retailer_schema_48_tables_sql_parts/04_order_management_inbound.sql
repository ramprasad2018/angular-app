-- 4. Order Management (Inbound)
CREATE TABLE retailer.retailer_purchase_order (
    id SERIAL PRIMARY KEY,
    retailer_id INTEGER REFERENCES retailer.retailer(id),
    supplier_id TEXT,
    order_date DATE,
    status TEXT
);

CREATE TABLE retailer.purchase_order_item (
    id SERIAL PRIMARY KEY,
    purchase_order_id INTEGER REFERENCES retailer.retailer_purchase_order(id),
    product_id INTEGER REFERENCES retailer.product(id),
    quantity INTEGER,
    price NUMERIC
);

CREATE TABLE retailer.goods_receipt_note (
    id SERIAL PRIMARY KEY,
    purchase_order_id INTEGER REFERENCES retailer.retailer_purchase_order(id),
    received_date DATE,
    verified_by TEXT
);

CREATE TABLE retailer.supplier_rating (
    id SERIAL PRIMARY KEY,
    supplier_id TEXT,
    rating INTEGER,
    feedback TEXT,
    rated_at TIMESTAMP
);