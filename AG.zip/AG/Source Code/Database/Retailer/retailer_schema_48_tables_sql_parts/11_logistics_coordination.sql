-- 11. Logistics Coordination
CREATE TABLE retailer.local_delivery_schedule (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES retailer.sales_invoice(id),
    delivery_date DATE,
    delivery_slot TEXT
);

CREATE TABLE retailer.delivery_partner_assignment (
    id SERIAL PRIMARY KEY,
    delivery_id INTEGER REFERENCES retailer.local_delivery_schedule(id),
    partner_name TEXT,
    assigned_at TIMESTAMP
);

CREATE TABLE retailer.delivery_proof (
    id SERIAL PRIMARY KEY,
    delivery_id INTEGER REFERENCES retailer.local_delivery_schedule(id),
    proof_type TEXT,
    proof_data TEXT,
    submitted_at TIMESTAMP
);

CREATE TABLE retailer.delivery_status_log (
    id SERIAL PRIMARY KEY,
    delivery_id INTEGER REFERENCES retailer.local_delivery_schedule(id),
    status TEXT,
    updated_at TIMESTAMP
);