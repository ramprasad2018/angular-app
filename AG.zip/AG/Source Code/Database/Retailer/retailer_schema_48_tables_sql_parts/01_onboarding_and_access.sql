-- 1. Retailer Onboarding & Access Management
CREATE SCHEMA IF NOT EXISTS retailer;

CREATE TABLE retailer.retailer (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    business_type TEXT,
    gstin TEXT,
    license_number TEXT,
    location TEXT,
    registration_date TIMESTAMP DEFAULT now()
);

CREATE TABLE retailer.retailer_user (
    id SERIAL PRIMARY KEY,
    retailer_id INTEGER REFERENCES retailer.retailer(id),
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT,
    active BOOLEAN DEFAULT true
);

CREATE TABLE retailer.retailer_role (
    id SERIAL PRIMARY KEY,
    role_name TEXT NOT NULL,
    permissions TEXT
);

CREATE TABLE retailer.retailer_kyc_document (
    id SERIAL PRIMARY KEY,
    retailer_id INTEGER REFERENCES retailer.retailer(id),
    document_type TEXT,
    file_url TEXT,
    uploaded_at TIMESTAMP DEFAULT now()
);