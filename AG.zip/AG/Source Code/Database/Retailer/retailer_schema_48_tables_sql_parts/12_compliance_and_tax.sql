-- 12. Compliance & Tax
CREATE TABLE retailer.gst_invoice_log (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES retailer.sales_invoice(id),
    gst_number TEXT,
    hsn_code TEXT,
    gst_amount NUMERIC
);

CREATE TABLE retailer.gst_monthly_report (
    id SERIAL PRIMARY KEY,
    retailer_id INTEGER REFERENCES retailer.retailer(id),
    month TEXT,
    total_tax_paid NUMERIC
);

CREATE TABLE retailer.license_expiry_alert (
    id SERIAL PRIMARY KEY,
    retailer_id INTEGER REFERENCES retailer.retailer(id),
    license_type TEXT,
    expiry_date DATE,
    alert_sent BOOLEAN
);

CREATE TABLE retailer.digital_signature_log (
    id SERIAL PRIMARY KEY,
    document_type TEXT,
    document_id TEXT,
    signed_by TEXT,
    signed_at TIMESTAMP
);