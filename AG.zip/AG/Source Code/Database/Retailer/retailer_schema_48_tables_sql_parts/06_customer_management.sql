-- 6. Customer Management
CREATE TABLE retailer.customer_profile (
    id SERIAL PRIMARY KEY,
    phone TEXT UNIQUE,
    name TEXT,
    loyalty_points INTEGER DEFAULT 0
);

CREATE TABLE retailer.customer_feedback (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES retailer.customer_profile(id),
    feedback_text TEXT,
    rating INTEGER,
    submitted_at TIMESTAMP
);

CREATE TABLE retailer.loyalty_program (
    id SERIAL PRIMARY KEY,
    program_name TEXT,
    point_ratio NUMERIC,
    description TEXT
);

CREATE TABLE retailer.loyalty_transaction (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES retailer.customer_profile(id),
    points INTEGER,
    transaction_type TEXT,
    transaction_date DATE
);