-- 10. Integration Modules
CREATE TABLE retailer.supplier_integration_log (
    id SERIAL PRIMARY KEY,
    supplier_id TEXT,
    sync_status TEXT,
    synced_at TIMESTAMP
);

CREATE TABLE retailer.warehouse_integration_log (
    id SERIAL PRIMARY KEY,
    warehouse_id TEXT,
    stock_update_time TIMESTAMP
);

CREATE TABLE retailer.payment_gateway_log (
    id SERIAL PRIMARY KEY,
    transaction_id TEXT,
    gateway_name TEXT,
    amount NUMERIC,
    status TEXT,
    processed_at TIMESTAMP
);

CREATE TABLE retailer.qr_label_print_log (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    printed_by TEXT,
    printed_at TIMESTAMP
);