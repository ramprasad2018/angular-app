-- 2. Product Catalog Management
CREATE TABLE retailer.product_category (
    id SERIAL PRIMARY KEY,
    name TEXT,
    description TEXT
);

CREATE TABLE retailer.product (
    id SERIAL PRIMARY KEY,
    category_id INTEGER REFERENCES retailer.product_category(id),
    name TEXT,
    brand TEXT,
    sku TEXT UNIQUE
);

CREATE TABLE retailer.product_price_unit (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    unit TEXT,
    mrp NUMERIC,
    retail_price NUMERIC
);

CREATE TABLE retailer.product_barcode (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    barcode TEXT UNIQUE,
    qr_code TEXT
);