-- 8. Pricing & Offers
CREATE TABLE retailer.pricing_rule (
    id SERIAL PRIMARY KEY,
    rule_name TEXT,
    description TEXT,
    active BOOLEAN DEFAULT true
);

CREATE TABLE retailer.time_based_offer (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    discount_percent NUMERIC,
    start_time TIMESTAMP,
    end_time TIMESTAMP
);

CREATE TABLE retailer.combo_offer (
    id SERIAL PRIMARY KEY,
    combo_name TEXT,
    description TEXT,
    active BOOLEAN DEFAULT true
);

CREATE TABLE retailer.wholesale_pricing (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    min_quantity INTEGER,
    discounted_price NUMERIC
);