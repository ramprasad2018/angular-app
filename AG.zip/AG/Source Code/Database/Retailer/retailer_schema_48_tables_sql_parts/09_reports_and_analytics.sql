-- 9. Reports & Analytics
CREATE TABLE retailer.daily_sales_summary (
    id SERIAL PRIMARY KEY,
    retailer_id INTEGER REFERENCES retailer.retailer(id),
    report_date DATE,
    total_revenue NUMERIC,
    total_orders INTEGER
);

CREATE TABLE retailer.inventory_report (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    current_stock INTEGER,
    slow_moving BOOLEAN,
    expired BOOLEAN
);

CREATE TABLE retailer.profit_margin_report (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES retailer.product(id),
    cost_price NUMERIC,
    selling_price NUMERIC,
    margin NUMERIC
);

CREATE TABLE retailer.customer_analytics (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES retailer.customer_profile(id),
    repeat_visits INTEGER,
    average_spend NUMERIC
);