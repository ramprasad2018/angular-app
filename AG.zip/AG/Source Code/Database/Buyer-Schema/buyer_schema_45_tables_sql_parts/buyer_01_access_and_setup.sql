-- 1. Access & Setup

CREATE SCHEMA IF NOT EXISTS buyer;

CREATE TABLE buyer.buyer (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    gstin TEXT,
    license_number TEXT,
    contact TEXT,
    address TEXT,
    registration_date TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.buyer_user (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    username TEXT UNIQUE,
    password TEXT,
    role TEXT,
    active BOOLEAN DEFAULT true
);

CREATE TABLE buyer.buyer_role (
    id SERIAL PRIMARY KEY,
    role_name TEXT UNIQUE NOT NULL,
    description TEXT
);

CREATE TABLE buyer.buyer_approval_status (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    status TEXT,
    remarks TEXT,
    approved_at TIMESTAMP
);