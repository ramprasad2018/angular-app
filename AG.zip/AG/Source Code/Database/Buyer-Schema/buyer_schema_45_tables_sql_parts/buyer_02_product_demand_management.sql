-- 2. Product Demand Management

CREATE TABLE buyer.procurement_demand (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    crop_type TEXT,
    quantity NUMERIC,
    delivery_date DATE,
    location TEXT
);

CREATE TABLE buyer.seasonal_demand_plan (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    crop TEXT,
    start_month TEXT,
    end_month TEXT,
    recurring BOOLEAN
);

CREATE TABLE buyer.demand_match_log (
    id SERIAL PRIMARY KEY,
    demand_id INTEGER REFERENCES buyer.procurement_demand(id),
    matched_supplier_id TEXT,
    matched_on TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.demand_forecast (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    crop TEXT,
    forecast_quantity NUMERIC,
    forecast_period TEXT
);