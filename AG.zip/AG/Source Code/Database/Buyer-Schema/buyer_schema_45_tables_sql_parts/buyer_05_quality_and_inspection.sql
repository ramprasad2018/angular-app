-- 5. Quality & Inspection

CREATE TABLE buyer.quality_standard (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    grade TEXT,
    moisture_limit NUMERIC,
    color_spec TEXT
);

CREATE TABLE buyer.inspection_schedule (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    scheduled_date DATE,
    method TEXT
);

CREATE TABLE buyer.inspection_report (
    id SERIAL PRIMARY KEY,
    schedule_id INTEGER REFERENCES buyer.inspection_schedule(id),
    grade TEXT,
    comments TEXT,
    photo_url TEXT
);

CREATE TABLE buyer.dispute_log (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    issue TEXT,
    status TEXT,
    raised_at TIMESTAMP DEFAULT now()
);