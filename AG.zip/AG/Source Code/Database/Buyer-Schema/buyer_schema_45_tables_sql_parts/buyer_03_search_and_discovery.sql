-- 3. Search & Discovery

CREATE TABLE buyer.farmer_search_log (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    search_term TEXT,
    searched_at TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.warehouse_search_log (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    search_term TEXT,
    searched_at TIMESTAMP DEFAULT now()
);