-- 12. Integration & Compliance

CREATE TABLE buyer.gst_invoice_log (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES buyer.buyer_invoice(id),
    gst_number TEXT,
    submitted_at TIMESTAMP
);

CREATE TABLE buyer.eway_bill (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    document_url TEXT,
    generated_at TIMESTAMP
);

CREATE TABLE buyer.buyer_erp_integration (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    erp_system TEXT,
    integration_token TEXT,
    last_synced_at TIMESTAMP
);