-- 10. Reports & Analytics

CREATE TABLE buyer.procurement_dashboard (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    crop TEXT,
    volume NUMERIC,
    average_price NUMERIC,
    report_date DATE
);

CREATE TABLE buyer.order_fulfillment_kpi (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    delay_days INTEGER,
    rejection_rate NUMERIC
);

CREATE TABLE buyer.buyer_spend_summary (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    season TEXT,
    total_spend NUMERIC
);

CREATE TABLE buyer.quality_acceptance_rate (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    accepted_batches INTEGER,
    rejected_batches INTEGER
);