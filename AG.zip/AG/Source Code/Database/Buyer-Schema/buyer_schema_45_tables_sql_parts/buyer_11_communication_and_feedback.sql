-- 11. Communication & Feedback

CREATE TABLE buyer.buyer_chat_message (
    id SERIAL PRIMARY KEY,
    sender_id TEXT,
    receiver_id TEXT,
    message TEXT,
    sent_at TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.buyer_enquiry (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    product_id TEXT,
    enquiry_text TEXT,
    submitted_at TIMESTAMP
);

CREATE TABLE buyer.buyer_feedback (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    supplier_id TEXT,
    rating INTEGER,
    comment TEXT,
    submitted_at TIMESTAMP
);

CREATE TABLE buyer.buyer_notification (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    message TEXT,
    notification_type TEXT,
    created_at TIMESTAMP DEFAULT now()
);