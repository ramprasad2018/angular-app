-- 4. Order Management

CREATE TABLE buyer.purchase_order (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    order_date DATE,
    total_amount NUMERIC,
    status TEXT
);

CREATE TABLE buyer.purchase_order_item (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    product_id TEXT,
    quantity INTEGER,
    unit_price NUMERIC
);

CREATE TABLE buyer.purchase_order_tracking (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    status TEXT,
    updated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.purchase_order_history (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    status TEXT,
    changed_at TIMESTAMP
);