-- 7. Inventory & Warehouse Coordination

CREATE TABLE buyer.warehouse_stock_view (
    id SERIAL PRIMARY KEY,
    warehouse_id TEXT,
    product_id TEXT,
    available_quantity INTEGER,
    last_checked TIMESTAMP
);

CREATE TABLE buyer.stock_reservation (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    product_id TEXT,
    reserved_quantity INTEGER,
    reserved_at TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.unloading_log (
    id SERIAL PRIMARY KEY,
    warehouse_id TEXT,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    verified_by TEXT,
    log_time TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.storage_request (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    warehouse_id TEXT,
    request_date DATE,
    duration_days INTEGER
);