-- 9. Billing & Payments

CREATE TABLE buyer.buyer_invoice (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    issued_date DATE,
    total_amount NUMERIC
);

CREATE TABLE buyer.buyer_payment (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES buyer.buyer_invoice(id),
    paid_amount NUMERIC,
    payment_method TEXT,
    payment_date DATE
);

CREATE TABLE buyer.payment_tracking (
    id SERIAL PRIMARY KEY,
    payment_id INTEGER REFERENCES buyer.buyer_payment(id),
    status TEXT,
    confirmed_at TIMESTAMP
);

CREATE TABLE buyer.buyer_credit_line (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    credit_limit NUMERIC,
    used_amount NUMERIC,
    valid_until DATE
);