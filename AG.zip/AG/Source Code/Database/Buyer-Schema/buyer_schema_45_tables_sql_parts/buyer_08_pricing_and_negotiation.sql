-- 8. Pricing & Negotiation

CREATE TABLE buyer.market_price_reference (
    id SERIAL PRIMARY KEY,
    crop TEXT,
    location TEXT,
    date DATE,
    average_price NUMERIC
);

CREATE TABLE buyer.counter_offer (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    proposed_price NUMERIC,
    response TEXT,
    created_at TIMESTAMP
);

CREATE TABLE buyer.bulk_discount_offer (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    min_quantity INTEGER,
    discount_percent NUMERIC
);

CREATE TABLE buyer.price_contract (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    crop TEXT,
    fixed_price NUMERIC,
    start_date DATE,
    end_date DATE
);