-- 6. Logistics Coordination

CREATE TABLE buyer.logistics_partner_selection (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES buyer.buyer(id),
    partner_id TEXT,
    selected_at TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.pickup_schedule (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    pickup_date DATE,
    instructions TEXT
);

CREATE TABLE buyer.shipment_tracking (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    location TEXT,
    status TEXT,
    updated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE buyer.delivery_confirmation (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES buyer.purchase_order(id),
    confirmed BOOLEAN,
    confirmed_at TIMESTAMP
);