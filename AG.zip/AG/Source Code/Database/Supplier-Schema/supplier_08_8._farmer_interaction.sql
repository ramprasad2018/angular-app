-- 8. Farmer Interaction
CREATE TABLE supplier.farmer_query (
    id SERIAL PRIMARY KEY,
    farmer_id TEXT,
    product_id INTEGER REFERENCES supplier.product(id),
    query_text TEXT,
    submitted_at TIMESTAMP DEFAULT now()
);

CREATE TABLE supplier.product_recommendation (
    id SERIAL PRIMARY KEY,
    farmer_id TEXT,
    recommended_products TEXT,
    recommended_on DATE
);

CREATE TABLE supplier.demo_request (
    id SERIAL PRIMARY KEY,
    farmer_id TEXT,
    product_id INTEGER REFERENCES supplier.product(id),
    requested_date DATE
);

CREATE TABLE supplier.farmer_feedback (
    id SERIAL PRIMARY KEY,
    farmer_id TEXT,
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    rating INTEGER,
    comments TEXT
);