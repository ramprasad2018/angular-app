-- 10. Integration
CREATE TABLE supplier.external_system_log (
    id SERIAL PRIMARY KEY,
    integration_point TEXT,
    payload TEXT,
    synced_at TIMESTAMP DEFAULT now()
);

CREATE TABLE supplier.erp_mapping (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES supplier.product(id),
    erp_code TEXT
);

CREATE TABLE supplier.supplier_notification (
    id SERIAL PRIMARY KEY,
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    message TEXT,
    sent_at TIMESTAMP DEFAULT now()
);