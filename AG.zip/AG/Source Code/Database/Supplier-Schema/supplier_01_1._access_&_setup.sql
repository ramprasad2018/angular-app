-- 1. Access & Setup
CREATE SCHEMA IF NOT EXISTS supplier;

CREATE TABLE supplier.supplier (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    gst_number TEXT,
    contact TEXT,
    address TEXT,
    registration_date TIMESTAMP DEFAULT now()
);

CREATE TABLE supplier.supplier_user (
    id SERIAL PRIMARY KEY,
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    username TEXT UNIQUE,
    password TEXT,
    role TEXT,
    active BOOLEAN DEFAULT true
);

CREATE TABLE supplier.supplier_role (
    id SERIAL PRIMARY KEY,
    role_name TEXT UNIQUE NOT NULL,
    description TEXT
);

CREATE TABLE supplier.supplier_kyc_document (
    id SERIAL PRIMARY KEY,
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    document_type TEXT,
    file_path TEXT,
    uploaded_at TIMESTAMP DEFAULT now()
);