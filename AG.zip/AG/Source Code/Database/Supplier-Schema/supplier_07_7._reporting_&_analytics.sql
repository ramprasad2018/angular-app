-- 7. Reporting & Analytics
CREATE TABLE supplier.supplier_sales_summary (
    id SERIAL PRIMARY KEY,
    report_date DATE,
    total_sales NUMERIC,
    top_product_id INTEGER
);

CREATE TABLE supplier.supplier_inventory_report (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES supplier.product(id),
    available_stock INTEGER,
    slow_moving BOOLEAN
);

CREATE TABLE supplier.supplier_performance_kpi (
    id SERIAL PRIMARY KEY,
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    order_acceptance_rate NUMERIC,
    tat NUMERIC
);