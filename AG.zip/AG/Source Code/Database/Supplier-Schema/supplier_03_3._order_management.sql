-- 3. Order Management
CREATE TABLE supplier.supplier_order (
    id SERIAL PRIMARY KEY,
    buyer_id TEXT,
    order_date TIMESTAMP DEFAULT now(),
    status TEXT
);

CREATE TABLE supplier.supplier_order_item (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES supplier.supplier_order(id),
    product_id INTEGER REFERENCES supplier.product(id),
    quantity INTEGER,
    price_per_unit NUMERIC
);

CREATE TABLE supplier.supplier_order_tracking (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES supplier.supplier_order(id),
    tracking_status TEXT,
    updated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE supplier.delivery_schedule (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES supplier.supplier_order(id),
    dispatch_date DATE,
    tracking_id TEXT
);

CREATE TABLE supplier.order_return (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES supplier.supplier_order(id),
    reason TEXT,
    status TEXT
);