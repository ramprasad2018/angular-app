-- 9. Compliance
CREATE TABLE supplier.product_certification (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES supplier.product(id),
    certification_type TEXT,
    file_url TEXT
);

CREATE TABLE supplier.regulatory_document (
    id SERIAL PRIMARY KEY,
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    document_type TEXT,
    valid_until DATE
);

CREATE TABLE supplier.gst_report (
    id SERIAL PRIMARY KEY,
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    report_month TEXT,
    total_tax NUMERIC
);