-- 5. Logistics Integration
CREATE TABLE supplier.delivery_partner (
    id SERIAL PRIMARY KEY,
    name TEXT,
    contact TEXT,
    service_area TEXT
);

CREATE TABLE supplier.delivery_challan (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES supplier.supplier_order(id),
    generated_at TIMESTAMP DEFAULT now(),
    remarks TEXT
);

CREATE TABLE supplier.shipment_return (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES supplier.supplier_order(id),
    reason TEXT,
    condition TEXT
);

CREATE TABLE supplier.delivery_status (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES supplier.supplier_order(id),
    status TEXT,
    updated_at TIMESTAMP DEFAULT now()
);