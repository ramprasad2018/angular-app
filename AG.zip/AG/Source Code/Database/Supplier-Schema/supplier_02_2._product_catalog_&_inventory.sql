-- 2. Product Catalog & Inventory
CREATE TABLE supplier.product_category (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT
);

CREATE TABLE supplier.product (
    id SERIAL PRIMARY KEY,
    category_id INTEGER REFERENCES supplier.product_category(id),
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    name TEXT,
    description TEXT,
    unit TEXT,
    status TEXT CHECK (status IN ('in_stock', 'out_of_stock', 'discontinued'))
);

CREATE TABLE supplier.product_unit_price (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES supplier.product(id),
    mrp NUMERIC,
    selling_price NUMERIC,
    effective_date DATE
);

CREATE TABLE supplier.product_stock (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES supplier.product(id),
    quantity INTEGER,
    last_updated TIMESTAMP DEFAULT now()
);

CREATE TABLE supplier.product_warehouse_assignment (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES supplier.product(id),
    warehouse_id INTEGER,
    assigned_quantity INTEGER
);

CREATE TABLE supplier.product_reorder_alert (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES supplier.product(id),
    threshold INTEGER
);