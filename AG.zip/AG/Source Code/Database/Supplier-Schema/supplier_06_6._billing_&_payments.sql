-- 6. Billing & Payments
CREATE TABLE supplier.supplier_invoice (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES supplier.supplier_order(id),
    invoice_date DATE,
    total_amount NUMERIC
);

CREATE TABLE supplier.supplier_payment (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES supplier.supplier_invoice(id),
    amount_paid NUMERIC,
    payment_method TEXT,
    payment_date DATE
);

CREATE TABLE supplier.supplier_payment_reconciliation (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES supplier.supplier_invoice(id),
    matched BOOLEAN DEFAULT false,
    remarks TEXT
);

CREATE TABLE supplier.supplier_due (
    id SERIAL PRIMARY KEY,
    supplier_id INTEGER REFERENCES supplier.supplier(id),
    amount NUMERIC,
    due_date DATE,
    status TEXT
);