-- 4. Procurement Planning
CREATE TABLE supplier.supplier_procurement_order (
    id SERIAL PRIMARY KEY,
    vendor_name TEXT,
    order_date TIMESTAMP DEFAULT now(),
    status TEXT
);

CREATE TABLE supplier.supplier_procurement_item (
    id SERIAL PRIMARY KEY,
    procurement_order_id INTEGER REFERENCES supplier.supplier_procurement_order(id),
    product_name TEXT,
    quantity INTEGER,
    expected_delivery DATE
);

CREATE TABLE supplier.inward_gate_entry (
    id SERIAL PRIMARY KEY,
    procurement_order_id INTEGER REFERENCES supplier.supplier_procurement_order(id),
    entry_date DATE,
    received_by TEXT
);