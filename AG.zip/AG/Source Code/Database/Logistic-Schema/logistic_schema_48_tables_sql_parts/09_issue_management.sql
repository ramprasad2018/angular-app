-- 9. Issue Management
CREATE TABLE logistic.damage_theft_report (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    description TEXT,
    image_url TEXT,
    reported_by TEXT,
    reported_at TIMESTAMP
);

CREATE TABLE logistic.logistics_escalation_log (
    id SERIAL PRIMARY KEY,
    issue_id INTEGER REFERENCES logistic.damage_theft_report(id),
    escalated_to TEXT,
    escalation_level TEXT,
    escalated_at TIMESTAMP
);

CREATE TABLE logistic.logistics_dispute (
    id SERIAL PRIMARY KEY,
    reference_id TEXT,
    dispute_reason TEXT,
    resolution_status TEXT,
    opened_at TIMESTAMP
);

CREATE TABLE logistic.return_trip_log (
    id SERIAL PRIMARY KEY,
    original_trip_id INTEGER REFERENCES logistic.trip_plan(id),
    return_reason TEXT,
    rerouted_by TEXT,
    return_start TIMESTAMP
);