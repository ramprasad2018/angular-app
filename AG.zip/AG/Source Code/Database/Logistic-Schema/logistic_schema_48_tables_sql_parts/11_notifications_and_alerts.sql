-- 11. Notifications & Alerts
CREATE TABLE logistic.logistics_notification (
    id SERIAL PRIMARY KEY,
    recipient TEXT,
    notification_type TEXT,
    message TEXT,
    sent_at TIMESTAMP
);

CREATE TABLE logistic.tracking_alert (
    id SERIAL PRIMARY KEY,
    vehicle_id INTEGER REFERENCES logistic.vehicle(id),
    alert_type TEXT,
    triggered_at TIMESTAMP
);

CREATE TABLE logistic.document_expiry_alert (
    id SERIAL PRIMARY KEY,
    document_type TEXT,
    vehicle_or_driver_id TEXT,
    expiry_date DATE,
    notified BOOLEAN
);

CREATE TABLE logistic.logistics_system_alert (
    id SERIAL PRIMARY KEY,
    alert_type TEXT,
    alert_message TEXT,
    triggered_at TIMESTAMP
);