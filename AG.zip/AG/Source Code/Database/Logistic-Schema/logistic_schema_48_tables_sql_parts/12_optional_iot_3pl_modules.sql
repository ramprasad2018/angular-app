-- 12. Optional IoT / 3PL Modules
CREATE TABLE logistic.iot_sensor_log (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    sensor_type TEXT,
    value NUMERIC,
    timestamp TIMESTAMP
);

CREATE TABLE logistic.qr_scan_log (
    id SERIAL PRIMARY KEY,
    reference_type TEXT,
    reference_id TEXT,
    scanned_at TIMESTAMP,
    scanned_by TEXT
);

CREATE TABLE logistic.third_party_logistics_api_log (
    id SERIAL PRIMARY KEY,
    provider_name TEXT,
    api_endpoint TEXT,
    payload TEXT,
    status TEXT,
    response_time_ms INTEGER,
    called_at TIMESTAMP
);