-- 4. Shipment Tracking
CREATE TABLE logistic.gps_tracking_log (
    id SERIAL PRIMARY KEY,
    vehicle_id INTEGER REFERENCES logistic.vehicle(id),
    latitude NUMERIC,
    longitude NUMERIC,
    recorded_at TIMESTAMP
);

CREATE TABLE logistic.eta_log (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    eta TIMESTAMP,
    recalculated_at TIMESTAMP
);

CREATE TABLE logistic.route_deviation_alert (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    alert_message TEXT,
    alert_time TIMESTAMP
);

CREATE TABLE logistic.handover_log (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    event TEXT CHECK (event IN ('pickup', 'dropoff')),
    timestamp TIMESTAMP,
    location TEXT
);