-- 7. Freight & Billing
CREATE TABLE logistic.freight_rate_card (
    id SERIAL PRIMARY KEY,
    vehicle_type TEXT,
    base_distance_km INTEGER,
    rate_per_km NUMERIC
);

CREATE TABLE logistic.freight_calculation (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    distance NUMERIC,
    calculated_amount NUMERIC
);

CREATE TABLE logistic.logistics_invoice (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    invoice_date DATE,
    total_amount NUMERIC
);

CREATE TABLE logistic.logistics_payment (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES logistic.logistics_invoice(id),
    paid_amount NUMERIC,
    payment_method TEXT,
    payment_date DATE
);