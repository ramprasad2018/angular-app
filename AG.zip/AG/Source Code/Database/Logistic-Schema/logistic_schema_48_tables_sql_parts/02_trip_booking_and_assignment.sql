-- 2. Trip Booking & Assignment
CREATE TABLE logistic.delivery_request (
    id SERIAL PRIMARY KEY,
    source_module TEXT,
    source_reference_id TEXT,
    created_by TEXT,
    created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE logistic.trip_plan (
    id SERIAL PRIMARY KEY,
    delivery_request_id INTEGER REFERENCES logistic.delivery_request(id),
    route_plan TEXT,
    estimated_start TIMESTAMP,
    estimated_end TIMESTAMP
);

CREATE TABLE logistic.auto_assignment_log (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    vehicle_id INTEGER REFERENCES logistic.vehicle(id),
    driver_id INTEGER REFERENCES logistic.driver(id),
    assigned_at TIMESTAMP DEFAULT now()
);

CREATE TABLE logistic.manual_trip_assignment (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    dispatcher TEXT,
    reason TEXT,
    assigned_at TIMESTAMP
);