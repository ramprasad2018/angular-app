-- 10. Dashboard & Reports
CREATE TABLE logistic.fleet_utilization_report (
    id SERIAL PRIMARY KEY,
    report_date DATE,
    total_vehicles INTEGER,
    active_vehicles INTEGER,
    idle_vehicles INTEGER
);

CREATE TABLE logistic.trip_summary_report (
    id SERIAL PRIMARY KEY,
    date_range TEXT,
    completed_trips INTEGER,
    delayed_trips INTEGER
);

CREATE TABLE logistic.logistics_cost_report (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    fuel_cost NUMERIC,
    toll_cost NUMERIC,
    maintenance_cost NUMERIC
);

CREATE TABLE logistic.delivery_tat_report (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    pickup_time TIMESTAMP,
    delivery_time TIMESTAMP,
    tat_minutes INTEGER
);