-- 6. Load & Capacity Optimization
CREATE TABLE logistic.load_plan (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    planned_weight NUMERIC,
    planned_volume NUMERIC
);

CREATE TABLE logistic.route_optimization_log (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    recommended_route TEXT,
    executed_route TEXT,
    optimized_at TIMESTAMP
);

CREATE TABLE logistic.cold_chain_assignment (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    temperature_range TEXT,
    sensor_configured BOOLEAN
);

CREATE TABLE logistic.vehicle_suggestion_log (
    id SERIAL PRIMARY KEY,
    request_id INTEGER REFERENCES logistic.delivery_request(id),
    suggested_vehicle_id INTEGER REFERENCES logistic.vehicle(id),
    reason TEXT
);