-- 3. Vehicle & Driver Management
CREATE TABLE logistic.vehicle_availability_log (
    id SERIAL PRIMARY KEY,
    vehicle_id INTEGER REFERENCES logistic.vehicle(id),
    status TEXT CHECK (status IN ('available', 'in_use', 'maintenance')),
    updated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE logistic.driver_availability_log (
    id SERIAL PRIMARY KEY,
    driver_id INTEGER REFERENCES logistic.driver(id),
    status TEXT CHECK (status IN ('active', 'inactive')),
    updated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE logistic.driver_trip_log (
    id SERIAL PRIMARY KEY,
    driver_id INTEGER REFERENCES logistic.driver(id),
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    completed BOOLEAN,
    completed_at TIMESTAMP
);

CREATE TABLE logistic.driver_rating (
    id SERIAL PRIMARY KEY,
    driver_id INTEGER REFERENCES logistic.driver(id),
    rating INTEGER,
    feedback TEXT,
    submitted_by TEXT,
    submitted_at TIMESTAMP
);