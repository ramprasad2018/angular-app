-- 1. Logistics Partner Onboarding & Management
CREATE SCHEMA IF NOT EXISTS logistic;

CREATE TABLE logistic.logistic_partner (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    contact TEXT,
    registration_date TIMESTAMP DEFAULT now()
);

CREATE TABLE logistic.partner_kyc_document (
    id SERIAL PRIMARY KEY,
    partner_id INTEGER REFERENCES logistic.logistic_partner(id),
    document_type TEXT,
    document_url TEXT,
    uploaded_at TIMESTAMP DEFAULT now()
);

CREATE TABLE logistic.vehicle (
    id SERIAL PRIMARY KEY,
    partner_id INTEGER REFERENCES logistic.logistic_partner(id),
    license_plate TEXT UNIQUE,
    vehicle_type TEXT,
    capacity INTEGER,
    gps_enabled BOOLEAN,
    cold_chain_enabled BOOLEAN
);

CREATE TABLE logistic.driver (
    id SERIAL PRIMARY KEY,
    partner_id INTEGER REFERENCES logistic.logistic_partner(id),
    name TEXT,
    contact TEXT,
    license_number TEXT,
    aadhar_number TEXT
);

CREATE TABLE logistic.logistic_role_user (
    id SERIAL PRIMARY KEY,
    user_id TEXT,
    role TEXT CHECK (role IN ('admin', 'dispatcher', 'driver', 'support')),
    assigned_at TIMESTAMP DEFAULT now()
);