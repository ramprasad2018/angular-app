-- 5. Pickup & Delivery Operations
CREATE TABLE logistic.pickup_schedule (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    scheduled_time TIMESTAMP,
    location TEXT
);

CREATE TABLE logistic.delivery_confirmation (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    confirmed_by TEXT,
    confirmation_time TIMESTAMP
);

CREATE TABLE logistic.proof_of_delivery (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    photo_url TEXT,
    signature_url TEXT,
    submitted_at TIMESTAMP
);

CREATE TABLE logistic.failed_delivery_log (
    id SERIAL PRIMARY KEY,
    trip_id INTEGER REFERENCES logistic.trip_plan(id),
    reason TEXT,
    notes TEXT,
    logged_at TIMESTAMP
);