-- 8. Integration with Other Subsystems
CREATE TABLE logistic.fms_integration_log (
    id SERIAL PRIMARY KEY,
    request_id TEXT,
    log_time TIMESTAMP,
    status TEXT
);

CREATE TABLE logistic.supplier_integration_log (
    id SERIAL PRIMARY KEY,
    dispatch_id TEXT,
    synced_at TIMESTAMP,
    success BOOLEAN
);

CREATE TABLE logistic.warehouse_integration_log (
    id SERIAL PRIMARY KEY,
    batch_id TEXT,
    dispatch_id TEXT,
    synced_at TIMESTAMP
);

CREATE TABLE logistic.buyer_integration_log (
    id SERIAL PRIMARY KEY,
    delivery_id TEXT,
    confirmed BOOLEAN,
    confirmed_at TIMESTAMP
);