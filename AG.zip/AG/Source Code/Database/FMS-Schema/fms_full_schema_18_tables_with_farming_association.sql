
-- Create schema
CREATE SCHEMA IF NOT EXISTS fms;

CREATE TABLE fms.users (
    user_id SERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'FARMER',
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    farmer_id INT NULL,
    created_at TIMESTAMP DEFAULT now(),
    last_login TIMESTAMP,
    CONSTRAINT fk_farmer FOREIGN KEY (farmer_id)
        REFERENCES fms.farmer(id)
        ON DELETE SET NULL
);


-- Farmer table (with type field)
DROP TABLE IF EXISTS fms.farmer CASCADE;

CREATE TABLE fms.farmer (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT,
    type TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Farm table (linked to farmer)
CREATE TABLE IF NOT EXISTS fms.farm (
    id SERIAL PRIMARY KEY,
    farmer_id INTEGER NOT NULL REFERENCES fms.farmer(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    location TEXT,
    size_in_acres NUMERIC,
    crop_type TEXT,
    soil_quality TEXT,
    irrigation_type TEXT,
    created_at TIMESTAMP DEFAULT now()
);

-- Crop planning
CREATE TABLE IF NOT EXISTS fms.crop_plan (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER NOT NULL REFERENCES fms.farm(id) ON DELETE CASCADE,
    crop_name TEXT NOT NULL,
    planting_date DATE NOT NULL,
    expected_harvest_date DATE,
    seed_type TEXT,
    fertilizer_plan TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT now()
);


-- Soil test report
CREATE TABLE IF NOT EXISTS fms.soil_test (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER NOT NULL REFERENCES fms.farm(id) ON DELETE CASCADE,
    test_date DATE NOT NULL,
    ph_level NUMERIC,
    nitrogen_level NUMERIC,
    phosphorus_level NUMERIC,
    potassium_level NUMERIC,
    organic_matter TEXT,
    recommendations TEXT,
    created_at TIMESTAMP DEFAULT now()
);


-- Irrigation schedule
CREATE TABLE IF NOT EXISTS fms.irrigation_schedule (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER NOT NULL REFERENCES fms.farm(id) ON DELETE CASCADE,
    scheduled_date DATE NOT NULL,
    method TEXT, -- (e.g., drip, sprinkler, flood)
    water_quantity NUMERIC, -- in liters
    status TEXT DEFAULT 'Scheduled', -- values: Scheduled, Completed, Skipped
    notes TEXT,
    created_at TIMESTAMP DEFAULT now()
);



CREATE TABLE IF NOT EXISTS fms.irrigation_schedule (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER NOT NULL REFERENCES fms.farm(id) ON DELETE CASCADE,
    scheduled_date DATE NOT NULL,
    method TEXT, -- (e.g., drip, sprinkler, flood)
    water_quantity NUMERIC, -- in liters
    status TEXT DEFAULT 'Scheduled', -- values: Scheduled, Completed, Skipped
    notes TEXT,
    created_at TIMESTAMP DEFAULT now()
);



-- Equipment inventory
CREATE TABLE IF NOT EXISTS fms.equipment_inventory (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    equipment_name TEXT,
    quantity INTEGER,
    condition TEXT
);

-- Weather forecast
CREATE TABLE IF NOT EXISTS fms.weather_forecast (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    forecast_date DATE,
    temperature NUMERIC,
    humidity NUMERIC,
    rain_probability NUMERIC
);

-- Disease and pest record
CREATE TABLE IF NOT EXISTS fms.disease_pest_record (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    report_date DATE,
    issue_type TEXT,
    severity TEXT,
    notes TEXT
);

-- Harvest record
CREATE TABLE IF NOT EXISTS fms.harvest_record (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    harvest_date DATE,
    crop TEXT,
    yield_quantity NUMERIC
);

-- Sales record
CREATE TABLE IF NOT EXISTS fms.sales_record (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    sale_date DATE,
    crop TEXT,
    quantity NUMERIC,
    price_per_unit NUMERIC
);

-- Fertilizer usage
CREATE TABLE IF NOT EXISTS fms.fertilizer_usage (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    application_date DATE,
    fertilizer_type TEXT,
    quantity NUMERIC
);

-- Pesticide usage
CREATE TABLE IF NOT EXISTS fms.pesticide_usage (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    application_date DATE,
    pesticide_type TEXT,
    quantity NUMERIC
);

-- Water usage log
CREATE TABLE IF NOT EXISTS fms.water_usage_log (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    usage_date DATE,
    liters_used NUMERIC
);

-- Labour record
CREATE TABLE IF NOT EXISTS fms.labour_record (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    labourer_name TEXT,
    work_date DATE,
    hours_worked NUMERIC
);

-- Farm expense
CREATE TABLE IF NOT EXISTS fms.farm_expense (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    expense_date DATE,
    expense_type TEXT,
    amount NUMERIC
);

-- Farm revenue
CREATE TABLE IF NOT EXISTS fms.farm_revenue (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    revenue_date DATE,
    source TEXT,
    amount NUMERIC
);

-- Activity log
CREATE TABLE IF NOT EXISTS fms.farm_activity_log (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    activity_date DATE,
    activity_type TEXT,
    notes TEXT
);

-- Dashboard metrics snapshot
CREATE TABLE IF NOT EXISTS fms.dashboard_snapshot (
    id SERIAL PRIMARY KEY,
    farm_id INTEGER REFERENCES fms.farm(id),
    snapshot_date DATE,
    json_data TEXT
);
