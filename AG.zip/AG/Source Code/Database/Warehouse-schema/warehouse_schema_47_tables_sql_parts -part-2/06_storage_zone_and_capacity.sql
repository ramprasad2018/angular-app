-- 6. Storage Zone & Capacity
CREATE TABLE warehouse.storage_zone (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    zone_type TEXT,
    description TEXT
);

CREATE TABLE warehouse.rack_allocation (
    id SERIAL PRIMARY KEY,
    zone_id INTEGER REFERENCES warehouse.storage_zone(id),
    batch_id INTEGER REFERENCES warehouse.batch(id),
    rack_number TEXT
);

CREATE TABLE warehouse.capacity_utilization (
    id SERIAL PRIMARY KEY,
    zone_id INTEGER REFERENCES warehouse.storage_zone(id),
    capacity INTEGER,
    used_capacity INTEGER,
    captured_at TIMESTAMP DEFAULT now()
);

CREATE TABLE warehouse.auto_block_entry (
    id SERIAL PRIMARY KEY,
    zone_id INTEGER REFERENCES warehouse.storage_zone(id),
    is_blocked BOOLEAN,
    reason TEXT,
    blocked_at TIMESTAMP
);