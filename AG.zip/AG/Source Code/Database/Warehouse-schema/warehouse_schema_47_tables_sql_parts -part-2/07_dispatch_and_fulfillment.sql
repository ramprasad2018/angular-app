-- 7. Dispatch & Order Fulfillment
CREATE TABLE warehouse.pick_list (
    id SERIAL PRIMARY KEY,
    order_id TEXT,
    product TEXT,
    quantity INTEGER,
    prepared_by TEXT,
    prepared_at TIMESTAMP
);

CREATE TABLE warehouse.dispatch_schedule (
    id SERIAL PRIMARY KEY,
    order_id TEXT,
    vehicle_number TEXT,
    dispatch_time TIMESTAMP
);

CREATE TABLE warehouse.delivery_challan (
    id SERIAL PRIMARY KEY,
    dispatch_id INTEGER REFERENCES warehouse.dispatch_schedule(id),
    challan_number TEXT,
    generated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE warehouse.dispatch_update (
    id SERIAL PRIMARY KEY,
    dispatch_id INTEGER REFERENCES warehouse.dispatch_schedule(id),
    status TEXT,
    updated_at TIMESTAMP DEFAULT now()
);