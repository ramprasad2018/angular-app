-- 1. Warehouse Onboarding & Access Management
CREATE SCHEMA IF NOT EXISTS warehouse;

CREATE TABLE warehouse.warehouse (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    location TEXT,
    capacity INTEGER,
    license_number TEXT,
    registered_at TIMESTAMP DEFAULT now()
);

CREATE TABLE warehouse.warehouse_user (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT,
    active BOOLEAN DEFAULT true
);

CREATE TABLE warehouse.warehouse_role (
    id SERIAL PRIMARY KEY,
    role_name TEXT NOT NULL UNIQUE,
    permissions TEXT
);

CREATE TABLE warehouse.warehouse_kyc_document (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    document_type TEXT,
    file_url TEXT,
    uploaded_at TIMESTAMP DEFAULT now()
);