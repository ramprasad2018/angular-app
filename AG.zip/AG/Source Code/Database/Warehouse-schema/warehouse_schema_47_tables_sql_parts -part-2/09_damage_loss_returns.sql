-- 9. Damage, Loss & Returns Handling
CREATE TABLE warehouse.damage_report (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER,
    description TEXT,
    reported_by TEXT,
    quantity INTEGER,
    reported_at TIMESTAMP
);

CREATE TABLE warehouse.insurance_claim (
    id SERIAL PRIMARY KEY,
    damage_report_id INTEGER REFERENCES warehouse.damage_report(id),
    claim_amount NUMERIC,
    status TEXT,
    submitted_at TIMESTAMP
);

CREATE TABLE warehouse.returns_management (
    id SERIAL PRIMARY KEY,
    order_id TEXT,
    product TEXT,
    reason TEXT,
    quantity INTEGER,
    returned_at TIMESTAMP
);

CREATE TABLE warehouse.disposal_log (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER,
    reason TEXT,
    disposed_by TEXT,
    quantity INTEGER,
    disposal_date DATE
);