-- 5. Inventory Management
CREATE TABLE warehouse.batch (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    product TEXT,
    quantity INTEGER,
    arrival_date DATE
);

CREATE TABLE warehouse.stock_quantity (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER REFERENCES warehouse.batch(id),
    current_quantity INTEGER,
    last_updated TIMESTAMP DEFAULT now()
);

CREATE TABLE warehouse.shelf_life_tracking (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER REFERENCES warehouse.batch(id),
    expiry_date DATE,
    status TEXT
);

CREATE TABLE warehouse.inventory_flow_policy (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    policy TEXT CHECK (policy IN ('FIFO', 'LIFO'))
);