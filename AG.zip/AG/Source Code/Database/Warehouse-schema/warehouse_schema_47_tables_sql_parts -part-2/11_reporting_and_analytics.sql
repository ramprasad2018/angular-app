-- 11. Reporting & Analytics
CREATE TABLE warehouse.stock_ledger (
    id SERIAL PRIMARY KEY,
    product TEXT,
    in_quantity INTEGER,
    out_quantity INTEGER,
    balance INTEGER,
    entry_date DATE
);

CREATE TABLE warehouse.storage_utilization_stats (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    date DATE,
    total_capacity INTEGER,
    used_capacity INTEGER
);

CREATE TABLE warehouse.entry_exit_log (
    id SERIAL PRIMARY KEY,
    gate_type TEXT,
    vehicle_number TEXT,
    timestamp TIMESTAMP,
    entered_by TEXT
);


CREATE TABLE warehouse.performance_kpi (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    turnaround_time INTEGER,
    spoilage_percent NUMERIC,
    rejection_rate NUMERIC
);