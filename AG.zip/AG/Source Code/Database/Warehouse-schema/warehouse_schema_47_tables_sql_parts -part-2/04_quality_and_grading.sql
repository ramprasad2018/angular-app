-- 4. Quality Inspection & Grading
CREATE TABLE warehouse.initial_inspection (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER,
    inspection_type TEXT,
    inspector TEXT,
    result TEXT,
    inspected_at TIMESTAMP
);

CREATE TABLE warehouse.sample_collection (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER,
    moisture_level NUMERIC,
    damage_level TEXT,
    collected_by TEXT,
    collected_at TIMESTAMP
);

CREATE TABLE warehouse.grading_record (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER,
    grade TEXT,
    notes TEXT,
    graded_by TEXT,
    graded_at TIMESTAMP
);

CREATE TABLE warehouse.quality_rejection (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER,
    reason TEXT,
    rejected_by TEXT,
    rejected_at TIMESTAMP
);