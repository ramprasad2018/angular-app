-- 2. Farmer/Buyer Booking Interface
CREATE TABLE warehouse.booking_request (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    user_type TEXT,
    user_id TEXT,
    product TEXT,
    quantity INTEGER,
    requested_date DATE
);

CREATE TABLE warehouse.booking_slot (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER REFERENCES warehouse.booking_request(id),
    slot_time TIMESTAMP,
    status TEXT
);

CREATE TABLE warehouse.booking_approval (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER REFERENCES warehouse.booking_request(id),
    approved_by TEXT,
    approved_at TIMESTAMP,
    status TEXT
);

CREATE TABLE warehouse.booking_history (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER REFERENCES warehouse.booking_request(id),
    status TEXT,
    updated_at TIMESTAMP
);