-- 10. Audit & Compliance
CREATE TABLE warehouse.stock_audit_log (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER,
    auditor TEXT,
    findings TEXT,
    audit_date DATE
);

CREATE TABLE warehouse.compliance_log (
    id SERIAL PRIMARY KEY,
    compliance_type TEXT,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    report_url TEXT,
    report_date DATE
);

CREATE TABLE warehouse.batch_traceability (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER,
    source TEXT,
    stored_at DATE,
    dispatched_at DATE
);

CREATE TABLE warehouse.certificate_expiry_alert (
    id SERIAL PRIMARY KEY,
    document_type TEXT,
    expiry_date DATE,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    alert_sent BOOLEAN
);