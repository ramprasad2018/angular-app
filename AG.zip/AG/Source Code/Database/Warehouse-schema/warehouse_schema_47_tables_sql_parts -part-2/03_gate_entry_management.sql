-- 3. Gate Entry Management
CREATE TABLE warehouse.inward_gate_entry (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    vehicle_number TEXT,
    driver_name TEXT,
    product TEXT,
    quantity INTEGER,
    arrival_time TIMESTAMP
);

CREATE TABLE warehouse.outward_gate_entry (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    vehicle_number TEXT,
    dispatched_to TEXT,
    product TEXT,
    quantity INTEGER,
    dispatch_time TIMESTAMP
);

CREATE TABLE warehouse.entry_token (
    id SERIAL PRIMARY KEY,
    user_id TEXT,
    token TEXT,
    issue_time TIMESTAMP,
    valid_until TIMESTAMP
);

CREATE TABLE warehouse.weight_slip (
    id SERIAL PRIMARY KEY,
    gate_entry_id INTEGER,
    gross_weight NUMERIC,
    tare_weight NUMERIC,
    net_weight NUMERIC,
    captured_at TIMESTAMP
);