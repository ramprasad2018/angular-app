-- 12. Integration Modules
CREATE TABLE warehouse.fms_buyer_integration_log (
    id SERIAL PRIMARY KEY,
    source_system TEXT,
    reference_id TEXT,
    action TEXT,
    log_time TIMESTAMP DEFAULT now()
);

CREATE TABLE warehouse.iot_sensor_log (
    id SERIAL PRIMARY KEY,
    warehouse_id INTEGER REFERENCES warehouse.warehouse(id),
    sensor_type TEXT,
    reading_value NUMERIC,
    reading_time TIMESTAMP
);

CREATE TABLE warehouse.logistics_partner_integration (
    id SERIAL PRIMARY KEY,
    logistics_partner_id TEXT,
    order_id TEXT,
    integration_status TEXT,
    synced_at TIMESTAMP
);