-- 8. Billing & Charges
CREATE TABLE warehouse.storage_charge (
    id SERIAL PRIMARY KEY,
    batch_id INTEGER REFERENCES warehouse.batch(id),
    rate_per_day NUMERIC,
    total_days INTEGER,
    total_charge NUMERIC
);

CREATE TABLE warehouse.warehouse_invoice (
    id SERIAL PRIMARY KEY,
    customer_id TEXT,
    issue_date DATE,
    total_amount NUMERIC
);

CREATE TABLE warehouse.warehouse_payment (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER REFERENCES warehouse.warehouse_invoice(id),
    amount_paid NUMERIC,
    payment_method TEXT,
    payment_date DATE
);

CREATE TABLE warehouse.warehouse_due (
    id SERIAL PRIMARY KEY,
    customer_id TEXT,
    amount NUMERIC,
    due_date DATE,
    status TEXT
);